
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `subject_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_user_id_index` (`user_id`),
  KEY `activities_subject_id_index` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` (`id`, `user_id`, `subject_id`, `subject_type`, `type`, `created_at`, `updated_at`) VALUES (1,1,1,'Modules\\Forum\\Entities\\Reply','created_reply','2020-05-04 05:16:45','2020-05-04 05:16:45'),(2,1,2,'Modules\\Forum\\Entities\\Reply','created_reply','2020-05-07 21:10:07','2020-05-07 21:10:07'),(4,1,4,'Modules\\Forum\\Entities\\Reply','created_reply','2020-05-18 14:47:33','2020-05-18 14:47:33');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audits` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `event` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_id` bigint unsigned NOT NULL,
  `old_values` text COLLATE utf8mb4_unicode_ci,
  `new_values` text COLLATE utf8mb4_unicode_ci,
  `url` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audits_auditable_type_auditable_id_index` (`auditable_type`,`auditable_id`),
  KEY `audits_user_id_user_type_index` (`user_id`,`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `audits` DISABLE KEYS */;
INSERT INTO `audits` (`id`, `user_type`, `user_id`, `event`, `auditable_type`, `auditable_id`, `old_values`, `new_values`, `url`, `ip_address`, `user_agent`, `tags`, `created_at`, `updated_at`) VALUES (1,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-04-29 06:17:08','2020-04-29 06:17:08'),(2,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null}','{\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2020-04-29 07:17:08\",\"last_login_ip\":\"127.0.0.1\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-04-29 06:17:08','2020-04-29 06:17:08'),(3,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"avatar_type\":\"gravatar\",\"avatar_location\":null}','{\"avatar_type\":\"storage\",\"avatar_location\":\"avatars\\/wea1VntjEFHhggZJAMbb36GhRaxW5QfI2dp62Vgm.jpeg\"}','https://laravelcm.test/profile/avatar','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-04-29 06:41:29','2020-04-29 06:41:29'),(4,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"username\":null}','{\"username\":\"monneylobe\"}','https://laravelcm.test/profile/profile','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-04-29 06:41:36','2020-04-29 06:41:36'),(5,NULL,NULL,'created','Modules\\User\\Entities\\User',3,'[]','{\"first_name\":\"Mokam\",\"last_name\":\"Larissa\",\"username\":\"larissa\",\"email\":\"mokamtamnour@gmail.com\",\"active\":true,\"confirmed\":false,\"uuid\":\"504c01d1-4f4d-4df7-901a-b15004c85967\"}','https://laravelcm.test/register','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 03:32:41','2020-05-01 03:32:41'),(6,NULL,NULL,'updated','Modules\\User\\Entities\\User',3,'{\"confirmed\":0}','{\"confirmed\":true}','https://laravelcm.test/account/confirm/56c22e4ec7c989e8ace0e91cc5c17295','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 03:32:57','2020-05-01 03:32:57'),(7,'Modules\\User\\Entities\\User',3,'updated','Modules\\User\\Entities\\User',3,'[]','[]','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 03:33:17','2020-05-01 03:33:17'),(8,'Modules\\User\\Entities\\User',3,'updated','Modules\\User\\Entities\\User',3,'{\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null}','{\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2020-05-01 04:33:17\",\"last_login_ip\":\"127.0.0.1\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 03:33:17','2020-05-01 03:33:17'),(9,'Modules\\User\\Entities\\User',3,'updated','Modules\\User\\Entities\\User',3,'{\"avatar_type\":\"gravatar\",\"avatar_location\":null}','{\"avatar_type\":\"storage\",\"avatar_location\":\"avatars\\/JOE9u7K15eEp0Klw2E40QSPPlKGtyDSR75rZW5kL.jpeg\"}','https://laravelcm.test/profile/avatar','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 03:34:09','2020-05-01 03:34:09'),(10,'Modules\\User\\Entities\\User',3,'updated','Modules\\User\\Entities\\User',3,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 03:56:10','2020-05-01 03:56:10'),(11,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-04-29 07:17:08\"}','{\"last_login_at\":\"2020-05-01 23:40:52\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:75.0) Gecko/20100101 Firefox/75.0',NULL,'2020-05-01 22:40:52','2020-05-01 22:40:52'),(12,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-05-01 23:22:10','2020-05-01 23:22:10'),(13,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-01 23:40:52\"}','{\"last_login_at\":\"2020-05-02 00:53:35\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-05-01 23:53:35','2020-05-01 23:53:35'),(14,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-05-02 00:15:25','2020-05-02 00:15:25'),(15,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-02 00:53:35\"}','{\"last_login_at\":\"2020-05-02 21:09:08\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-05-02 20:09:08','2020-05-02 20:09:08'),(16,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"username\":\"monneylobe\"}','{\"username\":\"mckenziearts\"}','https://laravelcm.test/profile/profile','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',NULL,'2020-05-02 20:10:38','2020-05-02 20:10:38'),(17,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36',NULL,'2020-05-04 03:22:23','2020-05-04 03:22:23'),(18,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-02 21:09:08\"}','{\"last_login_at\":\"2020-05-04 05:32:22\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36',NULL,'2020-05-04 04:32:22','2020-05-04 04:32:22'),(19,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',NULL,'2020-05-20 06:56:37','2020-05-20 06:56:37'),(20,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-04 05:32:22\"}','{\"last_login_at\":\"2020-05-20 08:26:43\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',NULL,'2020-05-20 07:26:43','2020-05-20 07:26:43'),(21,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',NULL,'2020-05-20 07:50:25','2020-05-20 07:50:25'),(22,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-20 08:26:43\"}','{\"last_login_at\":\"2020-05-20 09:11:29\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',NULL,'2020-05-20 08:11:29','2020-05-20 08:11:29'),(23,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',NULL,'2020-05-21 04:41:08','2020-05-21 04:41:08'),(24,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-20 09:11:29\"}','{\"last_login_at\":\"2020-05-21 05:50:53\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',NULL,'2020-05-21 04:50:53','2020-05-21 04:50:53'),(25,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'[]','[]','https://laravelcm.test/logout','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',NULL,'2020-05-21 04:50:58','2020-05-21 04:50:58'),(26,'Modules\\User\\Entities\\User',1,'updated','Modules\\User\\Entities\\User',1,'{\"last_login_at\":\"2020-05-21 05:50:53\"}','{\"last_login_at\":\"2020-05-21 05:56:23\"}','https://laravelcm.test/login','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',NULL,'2020-05-21 04:56:23','2020-05-21 04:56:23');
/*!40000 ALTER TABLE `audits` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order` int NOT NULL DEFAULT '1',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `order`, `name`, `slug`, `created_at`, `updated_at`) VALUES (1,1,'Laravel','laravel','2020-04-29 07:18:45','2020-04-29 07:18:45'),(2,1,'React','react','2020-04-29 07:18:45','2020-04-29 07:18:45'),(3,1,'VueJS','vue-js','2020-04-29 07:18:45','2020-04-29 07:18:45'),(4,1,'JavaScript','javascript','2020-04-29 07:18:45','2020-04-29 07:18:45'),(5,1,'Développement Mobile','mobile-development','2020-04-29 07:18:45','2020-04-29 07:18:45'),(6,1,'Hosting','hosting','2020-04-29 07:18:45','2020-04-29 07:18:45'),(7,1,'Astuces','astuces-developpeur','2020-04-29 07:18:45','2020-04-29 07:18:45');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `channels_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES (1,'Laravel','laravel','2020-04-29 07:20:47','2020-04-29 07:20:47'),(2,'React','react','2020-04-29 07:20:47','2020-04-29 07:20:47'),(3,'Vue','vue','2020-04-29 07:20:47','2020-04-29 07:20:47'),(4,'JavaScript','javascript','2020-04-29 07:20:47','2020-04-29 07:20:47'),(5,'HTML/CSS','html-css','2020-04-29 07:20:47','2020-04-29 07:20:47'),(6,'PHP','php','2020-04-29 07:20:47','2020-04-29 07:20:47'),(7,'Design','design','2020-04-29 07:20:47','2020-04-29 07:20:47'),(8,'Feedback','feedback','2020-04-29 07:20:47','2020-04-29 07:20:47');
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `favorited_id` bigint unsigned NOT NULL,
  `favorited_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `favorites_user_id_favorited_id_favorited_type_unique` (`user_id`,`favorited_id`,`favorited_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `key_values` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `keyvalue_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyvalue_id` bigint unsigned NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_values_keyvalue_id_keyvalue_type_key_unique` (`keyvalue_id`,`keyvalue_type`,`key`),
  KEY `key_values_keyvalue_type_keyvalue_id_index` (`keyvalue_type`,`keyvalue_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `key_values` DISABLE KEYS */;
INSERT INTO `key_values` (`id`, `keyvalue_type`, `keyvalue_id`, `key`, `value`) VALUES (1,'Modules\\User\\Entities\\User',1,'biography','Je suis Full Stack Designer et Laravel Cameroun Site maintener'),(2,'Modules\\User\\Entities\\User',1,'address','Douala, Cameroun'),(3,'Modules\\User\\Entities\\User',1,'city','Douala'),(4,'Modules\\User\\Entities\\User',1,'postal_code','00237'),(5,'Modules\\User\\Entities\\User',1,'country','Cameroon'),(6,'Modules\\User\\Entities\\User',1,'state','Littoral');
/*!40000 ALTER TABLE `key_values` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `disk_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` smallint NOT NULL DEFAULT '1',
  `mediatable_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mediatable_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_mediatable_type_mediatable_id_index` (`mediatable_type`,`mediatable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` (`id`, `created_at`, `updated_at`, `disk_name`, `file_name`, `file_size`, `content_type`, `file_url`, `field`, `is_public`, `sort_order`, `mediatable_type`, `mediatable_id`) VALUES (1,'2020-04-30 01:33:22','2020-04-30 01:33:37','laravel-boilerplate-1588214002.png','laravel-boilerplate.png','4960','image/png','/uploads/laravel-boilerplate-1588214002.png','preview_image',1,1,'Modules\\Blog\\Entities\\Post',1),(2,'2020-04-30 01:39:24','2020-04-30 01:39:52','me-real-1588214364.jpg','me-real.jpg','173540','image/jpeg','/uploads/me-real-1588214364.jpg','preview_image',1,1,'Modules\\Blog\\Entities\\Post',2),(3,'2020-04-30 09:34:44','2020-04-30 09:34:47','fullstack-1588242884.jpg','fullstack.jpg','52289','image/jpeg','/uploads/fullstack-1588242884.jpg','preview_image',1,1,'Modules\\Tutorial\\Entities\\Tutorial',2),(4,'2020-04-30 11:10:00','2020-04-30 11:10:00','me-1588248600.jpg','me.jpg','29671','image/jpeg','/uploads/me-1588248600.jpg','preview_image',1,1,NULL,NULL),(5,'2020-04-30 11:15:15','2020-04-30 11:15:27','cameroon-start-up-conference-1588248915.jpg','cameroon-start-up-conference.jpg','75115','image/jpeg','/uploads/cameroon-start-up-conference-1588248915.jpg','preview_image',1,1,'Modules\\Tutorial\\Entities\\Tutorial',1),(7,'2020-05-01 22:41:15','2020-05-01 22:41:17','blog-flyer-1588376475.png','Blog Flyer.png','470957','image/png','/uploads/blog-flyer-1588376475.png','preview_image',1,1,'Modules\\Blog\\Entities\\Post',3),(8,'2020-05-11 11:53:09','2020-05-11 11:53:11','coming-soon-meetup-1589201589.jpg','coming-soon-meetup.jpg','670102','image/jpeg','/uploads/coming-soon-meetup-1589201589.jpg','preview_image',1,1,'Modules\\Blog\\Entities\\Post',5),(9,'2020-05-11 11:54:10','2020-05-11 11:54:15','lara-shopper-1589201650.png','lara-shopper.png','506577','image/png','/uploads/lara-shopper-1589201650.png','preview_image',1,1,'Modules\\Blog\\Entities\\Post',4);
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2017_03_14_180530_create_replies_table',1),(4,'2017_03_15_175959_create_threads_table',1),(5,'2017_03_30_161938_create_favorites_table',1),(6,'2017_04_21_162429_create_activities_table',1),(7,'2017_05_19_141013_create_thread_subscriptions_table',1),(8,'2017_09_03_144628_create_permission_tables',1),(9,'2017_09_11_174816_create_social_accounts_table',1),(10,'2017_09_26_140332_create_cache_table',1),(11,'2017_09_26_140528_create_sessions_table',1),(12,'2017_09_26_140609_create_jobs_table',1),(13,'2018_04_08_033256_create_password_histories_table',1),(14,'2019_03_26_000344_create_audits_table',1),(15,'2020_01_15_023552_create_categories_tables',1),(16,'2020_01_15_075436_create_categories_table',1),(17,'2020_01_15_075452_create_posts_table',1),(18,'2020_01_15_092619_create_tutorials_table',1),(19,'2020_02_06_121731_add_username_on_users_table',1),(20,'2020_02_17_043939_create_channels_table',1),(21,'2020_02_17_113621_create_notifications_table',1),(22,'2020_03_19_221625_create_media_table',1),(23,'2020_03_26_021501_create_key_values_table',1),(25,'2020_05_04_054230_add_timezone_column_to_users_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` int unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES (1,'Modules\\User\\Entities\\User',1),(2,'Modules\\User\\Entities\\User',2),(3,'Modules\\User\\Entities\\User',3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_histories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_histories_user_id_foreign` (`user_id`),
  CONSTRAINT `password_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `password_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_histories` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'view-backend','web','2020-04-29 06:16:53','2020-04-29 06:16:53');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT','PENDING') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `summary` text COLLATE utf8mb4_unicode_ci,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `visits` int unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL,
  `proposed_by` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_user_id_foreign` (`user_id`),
  KEY `posts_proposed_by_foreign` (`proposed_by`),
  CONSTRAINT `posts_proposed_by_foreign` FOREIGN KEY (`proposed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`id`, `title`, `body`, `image`, `slug`, `status`, `summary`, `featured`, `visits`, `user_id`, `proposed_by`, `category_id`, `published_at`, `created_at`, `updated_at`) VALUES (1,'Laravel 7 les nouveatés','Ceci est un contenu pour Laravel 7',NULL,'laravel-7-les-nouveates','PUBLISHED',NULL,0,3,1,NULL,1,'2020-04-30 01:33:37','2020-04-30 01:33:37','2020-05-01 03:37:06'),(2,'Migrer de React 15 pour React 16.4.10','Ceci est un article sur la migration de React',NULL,'migrer-de-react-15-pour-react-16410','PUBLISHED',NULL,0,7,1,NULL,2,'2020-04-30 11:00:00','2020-04-30 01:39:52','2020-05-07 21:49:13'),(3,'Laravel Cameroun Redesign (uses)','Laravel Cameroun est le site officiel de la Communauté Laravel & PHP au Cameroun. La communauté entre dans sans 2e année, et l\'idée pour la création d\'une communauté est venue lors d\'une conversation avec un ami ([Fabrice Yopa](https://github.com/fabriceyopa)) au vu de la popularité que gagnait le Framework dans notre pays et des offres d\'emploi qui revenaient régulièrement. Alors le site en est a sa 3e refonte.\r\n\r\nLes 2 premières n\'avaient pas beaucoup de vie ni te contenu alors après environ 3 mois de reflexion nous avons décidé de faire une refonte plus importante et de mettre un Forum actif a l\'image de celui présent sur [Laracasts](https://laracasts.com). Les contenus on été revu et le site est passé complètement en français, les ressources en anglais étant assez nombreuses ([Laravel](https://laravel.com), [Laravel News](https://laravel-news.com), [Laravel Jobs](https://larajobs.com), [Laracasts](https://laracasts.com) et la liste est longue.). Alors il ne s\'agit pas uniquement du site pour la Communauté camerounaise mais il s\'agit d\'un site `francophone` qui aura pour but d\'avoir un contenu en français pour les développeurs qui recherchent des ressources en français.\r\n\r\n### Technologies\r\n\r\n- [Laravel] (https://laravel.com) : Framework PHP \r\n- [InertiaJS] (https://inertiajs.com) : qui est un outil pour créer des SPA (Single Page Application) avec Laravel sans créer des API.\r\n- [Livewire] (https://laravel-livewire.com) : qui est un package Laravel qui permet de donner une approche component à votre code PHP et qui va le rendre dynamique\r\n- [TailwindCSS] (https://tailwindcss.com) et [TailwindUI](https://tailwindui.com) : mes coups de coeur, Framework CSS d\'utilitaire de classe et des composants créés par [Adman Wathan] (https://adamwathan.me)\r\n- [React] (https://reactjs.org) : Framework JavaScript créé par Facebook et qui est utilisé en association avec InertiaJS\r\n\r\n### Développement\r\n\r\n- [IntelliJ Idea](https://jetbrains) : Qui est un formidable IDE de développement créé par la société Jetbrains\r\n- [Github](https://github.com) : utilisé pour versioner le code. Le repos est sur le compte de la communauté ([cliquer ici](https://github.com/laravelcm))\r\n- [Trello](https://trello.com) : pour la gestion des tâches et les deadlines\r\n- QuickTime : les vidéos tutoriels pour la plus part sont enregistrées en utilisant le logiciel quicktime qui est disponible par défaut sur Mac.\r\n\r\n### Design\r\n\r\n- [Figma](https://figma.com) : les designs des premières version du site étaient réalisés sur Sketch, mais dans le but d\'étendre la collaboration avec d\'autres développeurs et designers nous avons opté pour Figma qui est plus scalable et qui est disponible sur toutes les plateformes (MacOS, Linux et Windows)\r\n- [SVGOMG] (https://jakearchibald.github.io/svgomg) : 90% des icônes et illustrations svg sont nettoyées par ce site.\r\n\r\n### Hosting\r\n\r\n- [Digital Ocean] (https://digitalocean.com) : Hébergeur qui propose de très bonnes solutions surtout sur le plan tarifaire et surtout qui est parfaitement intégré sur Laravel Forge\r\n- [Laravel Forge] (https://forge.laravel.com) : Laravel Forge qui est un outil créé par l\'auteur de Laravel est utilisé la gestion du code, et de tout ce qui est script d\'auto-déploiement du site, notification slack, Monitoring serveur, backups databases.\r\n- [CloudFlare] (https://www.cloudflare.com) : tout ce qui concerne la gestion des DNS et obtention des certificats sont gérés sur CloudFlare.\r\n\r\n### Référencement, Data Analytics & Marketing\r\n- [Google Master Tool] (https://www.google.com/webmasters)\r\n- [Google Analytics] (https://analytics.google.com/analytics/web)\r\n- [Google Tag Manager] (https://tagmanager.google.com)\r\n- [Mailgun] (https://www.mailgun.com) : Service utilisé pour l\'envoie des mails\r\n- [Mailchimp] (https://mailchimp.com) : Service pour l\'envoie des Newsletter\r\n\r\n\r\n### Manage Bugs\r\n- [Sentry] (https://sentry.io)',NULL,'laravel-cameroun-redesign-uses','PUBLISHED',NULL,0,14,1,NULL,7,'2020-05-01 05:15:00','2020-05-01 05:15:39','2020-06-19 05:29:26'),(4,'Laravel Shopper documentation','<p align=\"center\"><img height=\"100px\" src=\"https://pix.watch/k_qldx/tNOUs0.png\"></p>\r\n\r\n<p align=\"center\">\r\n<a href=\"https://travis-ci.org/mckenziearts/shopper\"><img src=\"https://travis-ci.org/mckenziearts/shopper.png?branch=master\"></a>\r\n<a href=\"https://packagist.org/packages/mckenziearts/shopper\"><img src=\"https://img.shields.io/packagist/v/mckenziearts/shopper.svg?style=flat-square\"></a>\r\n<a href=\"https://packagist.org/packages/mckenziearts/shopper\"><img src=\"https://img.shields.io/packagist/dt/mckenziearts/shopper.svg?style=flat-square\"></a>\r\n</p>\r\n\r\n## Introduction\r\n\r\nShopper is an Admin Management build for Laravel 5.6+ which includes all the necessary for your online market application. This project is inspired by [Orchid/Platform](https://github.com/orchidsoftware/platform).\r\nPlease note that this package is still under active development.\r\n\r\n![Shopper Screenshot](https://pix.watch/kvtzzS/NK1CPv.png)\r\n\r\n# Table of Contents\r\n\r\n1. [Requirements](#requirements)\r\n2. [Features](#features)\r\n3. [Installation](#installation)\r\n4. [Usage](#usage)\r\n5. [Documentation](#documentation)\r\n6. [Change log](#change-log)\r\n7. [Testing](#testing)\r\n8. [Contributing](#contributing)\r\n9. [Security](#security)\r\n10. [Credits](#credits) \r\n11. [License](#license)\r\n\r\n## Requirements\r\nMake sure your server meets the following requirements.\r\n\r\n-   Apache 2.2+ or nginx\r\n-   MySQL Server 5.7.8+ , Mariadb 10.3.2+ or PostgreSQL\r\n-   PHP Version 7.1.3+\r\n\r\n## Features\r\nIt packs in lots of demanding features that allows your shop to scale in no time:\r\n\r\n- [x] Responsive Layout\r\n- [x] Pace Loader\r\n- [x] Admin Authentication (With Sentinel)\r\n- [ ] Custom Admin Dashboard (E-commerce, Google Analytics)\r\n- [x] Automatic Validation Errors\r\n- [x] Element React\r\n- [x] React Component\r\n- [x] Multiple Locale, Currencies\r\n- [x] Image Cropper\r\n- [x] Orders Management System\r\n- [x] Tag Management System\r\n- [x] Discount Management System\r\n- [x] Coupon Management System\r\n- [x] Products, Related Products, Offers Management System\r\n- [x] Customers Management System\r\n- [x] Customer Cart, Wishlist, Product Reviews.\r\n- [x] Impersonate User\r\n- [ ] Custom attributes\r\n- [x] Social Media Post integration (Twitter & Facebook)\r\n- [x] Algolia Search\r\n- [ ] Translate Message\r\n- [ ] Custom configuration (Database download, Google Analytics)\r\n- [x] Open Source\r\n- [x] More to come..\r\n\r\n## Installation\r\n\r\nFirstly, download the Laravel installer using Composer:\r\n``` bash  \r\n$ composer require mckenziearts/shopper  \r\n```\r\nRun this command to install Shopper in your project\r\n```php\r\nphp artisan shopper:install\r\n```\r\nThis command will install shopper, publish vendor files, create shopper and storage symlinks if they don\'t exist in the public folder, run migrations and seeders classes.\r\n\r\nExtend your user model using the `Mckenziearts\\Shopper\\Plugins\\Users\\Models\\User as Authenticatable` alias:\r\n\r\n```php\r\nnamespace App;\r\n\r\nuse Mckenziearts\\Shopper\\Plugins\\Users\\Models\\User as Authenticatable;  \r\n  \r\nclass User extends Authenticatable  \r\n{  \r\n  \r\n}\r\n\r\n```\r\n\r\nRepublish Shopper\'s vendor files\r\n```php\r\nphp artisan vendor:publish --provider=\"Mckenziearts\\Shopper\\ShopperServiceProvider\"\r\nphp artisan vendor:publish --all\r\n```\r\n\r\nDuring publishing of shopper vendors files, shopper will add some others package\'s configurations files to your config folder : `larasap.php`, `scout.php`, `currencyConverter.php`, `laravellocalization.php` and `cartalyst.sentinel.php`\r\n\r\nIf you want to create an admin user use this command:\r\n```php\r\nphp artisan shopper:admin\r\n```\r\n\r\n## Usage\r\n\r\nRun laravel server\r\n```php\r\nphp artisan serve\r\n```\r\n\r\nTo view Shopper\'s dashboard go to:\r\n```php\r\nhttp://localhost:8000/console\r\n```\r\n\r\n## Documentation\r\nOfficial documentation is available [Here](https://docs.laravelshopper.com).\r\n\r\n\r\n## Change log  \r\n  \r\nPlease see the [changelog](changelog.md) for more information on what has changed recently.  \r\n  \r\n## Testing  \r\n  \r\n``` bash  \r\n$ composer test  \r\n```  \r\n  \r\n## Contributing  \r\n  \r\nPlease see [contributing.md](contributing.md) for details and a todolist.  \r\n  \r\n## Security  \r\n  \r\nIf you discover any security related issues, please email monneylobe@gmail.com instead of using the issue tracker.  \r\n  \r\n## Credits  \r\n  \r\n- [Arthur Monney](https://twitter.com/monneyarthur)\r\n- [Orchid Platform](https://github.com/orchidsoftware/platform)\r\n  \r\n## License  \r\n  \r\nMIT. Please see the [license file](license.md) for more information.  \r\n  \r\n[link-packagist]: https://packagist.org/packages/mckenziearts/shopper\r\n[link-downloads]: https://packagist.org/packages/mckenziearts/shopper',NULL,'laravel-shopper-documentation','PUBLISHED',NULL,0,13,1,1,1,'2020-05-11 11:54:15','2020-05-11 06:44:07','2020-06-18 17:02:29'),(5,'How to safely use React context','That should be enough to keep you far away from context right? Well of course not, it is a (unsupported) React feature, and forbidden features will be used for the mere fact that they exist! Context makes it possible to pass data to components deep in the component tree without needing intermediate components to know about it. Classic use cases for context are theming, localization and routing.\r\n\r\nDan Abramov has devised some wise rules when to leave this gem hanging in the tree:\r\n\r\nThe problematic coordination between context and SCU is clearly visible once you press the “Red please!” button (on the “Result” tab above). The button itself gets a fresh color, but the todo items are not updated. The reason for this is simple: our TodoList component is smart; it knows that whenever it receives no new todo items, it doesn’t need to re-render. (The smartness is achieved by inheriting from PureComponent which implements shouldComponentUpdate).\r\n\r\nHowever, due to this smartness (which is essential to keep React performant in big applications) the ThemedText components inside the TodoList don’t receive the new context with updated color! Because SCU returns false, neither the TodoList nor any of its descendants are updated.',NULL,'how-to-safely-use-react-context','PUBLISHED',NULL,0,2,1,3,2,'2020-05-11 11:52:00','2020-05-11 07:07:19','2020-05-11 12:07:35'),(8,'(🤩update) Can\'t perform a React state update on an unmounted component','### Problem\n\nI am writing an application in React and was unable to avoid a super common pitfall, which is calling `setState(...)` after `componentWillUnmount(...).`\n\nI looked very carefully at my code and tried to put some guarding clauses in place, but the problem persisted and I am still observing the warning.\n\nTherefore, I\'ve got two questions:\n\nHow do I figure out from the stack trace, which particular component and event handler or lifecycle hook is responsible for the rule violation?\nWell, how to fix the problem itself, because my code was written with this pitfall in mind and is already trying to prevent it, but some underlying component\'s still generating the warning.\n\n### Browser console\n\n```js\nWarning: Can\'t perform a React state update on an unmounted component.\nThis is a no-op, but it indicates a memory leak in your application.\nTo fix, cancel all subscriptions and asynchronous tasks in the componentWillUnmount\nmethod.\n    in TextLayerInternal (created by Context.Consumer)\n    in TextLayer (created by PageInternal) index.js:1446\nd/console[e]\nindex.js:1446\nwarningWithoutStack\nreact-dom.development.js:520\nwarnAboutUpdateOnUnmounted\nreact-dom.development.js:18238\nscheduleWork\nreact-dom.development.js:19684\nenqueueSetState\nreact-dom.development.js:12936\n./node_modules/react/cjs/react.development.js/Component.prototype.setState\nreact.development.js:356\n_callee$\nTextLayer.js:97\ntryCatch\nruntime.js:63\ninvoke\nruntime.js:282\ndefineIteratorMethods/</prototype[method]\nruntime.js:116\nasyncGeneratorStep\nasyncToGenerator.js:3\n_throw\nasyncToGenerator.js:29\n```\n\n![](https://i.stack.imgur.com/ATfMj.png)',NULL,'cant-perform-a-react-state-update-on-an-unmounted-component','PENDING',NULL,0,0,1,1,2,NULL,'2020-05-11 11:06:57','2020-05-11 11:29:02');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
INSERT INTO `replies` (`id`, `thread_id`, `user_id`, `body`, `created_at`, `updated_at`) VALUES (1,1,1,'Je met une reponse de test pour voir la date','2020-05-04 05:16:45','2020-05-04 05:16:45'),(2,2,1,'Je modifie ma réponse et je paste ce code pour que tu vois a quoi ca ressemble maintenant\n\n```php\n/**\n     * Update a reply on the storage.\n     *\n     * [@param](/u/@param)  ReplyRequest  $request\n     * [@param](/u/@param)  int  $id\n     * [@return](/u/@return) \\Illuminate\\Http\\JsonResponse\n     * [@throws](/u/@throws) \\Illuminate\\Auth\\Access\\AuthorizationException\n     */\n    public function update(ReplyRequest $request, $id)\n    {\n        $reply = Reply::find($id);\n\n        $this->authorize(\'update\', $reply);\n\n        $reply->update([\'body\' => $request->get(\'body\')]);\n\n        return response()->json([\'status\' => \'success\', \'message\' => \"Votre commentaire a été modifié\"]);\n    }\n```','2020-05-07 21:10:07','2020-05-18 14:45:27'),(4,2,1,'### The order of hooks\n\nA very important thing we have to understand is that we can’t change the order or numbers of the hooks in each render. It must be the same in every render. That means we can’t use conditional hooks. For e.g\n\n```js\nif (item) {\n    useEffect(() => {}) // you can\'t do this\n}\nor this \nitems.forEach(() => useEffect(() => {}))\n// because if the length of items changes the useEffect count will not be same in the next render.\n```','2020-05-18 14:47:33','2020-05-18 14:49:45');
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (1,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'administrator','Administrator','Site administrator with access to developer tools.','web','2020-04-29 06:16:53','2020-04-29 06:16:53'),(2,'publisher','Publisher','Site editor with access to publishing tools.','web','2020-04-29 06:16:53','2020-04-29 06:16:53'),(3,'user','User','Site user with simple access to website functionalities.','web','2020-04-29 06:16:53','2020-04-29 06:16:53');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_accounts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `social_accounts_user_id_foreign` (`user_id`),
  CONSTRAINT `social_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `social_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_accounts` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `thread_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `thread_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `thread_subscriptions_user_id_thread_id_unique` (`user_id`,`thread_id`),
  KEY `thread_subscriptions_thread_id_foreign` (`thread_id`),
  CONSTRAINT `thread_subscriptions_thread_id_foreign` FOREIGN KEY (`thread_id`) REFERENCES `threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `thread_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `thread_subscriptions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `threads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `channel_id` bigint unsigned NOT NULL,
  `replies_count` int unsigned NOT NULL DEFAULT '0',
  `visits` int unsigned NOT NULL DEFAULT '0',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `best_reply_id` bigint unsigned DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_posted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `threads_slug_unique` (`slug`),
  KEY `threads_best_reply_id_foreign` (`best_reply_id`),
  CONSTRAINT `threads_best_reply_id_foreign` FOREIGN KEY (`best_reply_id`) REFERENCES `replies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `threads` DISABLE KEYS */;
INSERT INTO `threads` (`id`, `title`, `slug`, `user_id`, `channel_id`, `replies_count`, `visits`, `body`, `best_reply_id`, `locked`, `created_at`, `updated_at`, `last_posted_at`) VALUES (1,'Mon sujet de test','mon-sujet-de-test',1,1,1,29,'un sujet demo',1,0,'2020-05-04 04:49:33','2020-05-20 05:59:16','2020-05-04 05:16:45'),(2,'useState and useEffect explained','usestate-and-useeffect-explained-twice-2',1,2,2,111,'This will cause `useEffect` to run after every render, just like `componentDidUpdate` but I doubt you would be using this a lot because most of the time we don’t want the side effects to run after every render.\n\nAnother use case for `useEffect` will be something like this\n\n```js\nlet [item, setItem] = useState(\'default value\')\nuseEffect(() => {\n    // hit an API\n}, [item])\nreturn (\n    <button onClick={() => setItem(\'Macbook Pro\')}>\n        Add Macbook Pro\n    </button>\n)\n```\n\nMost of the use case of `componentWillUnmount` is for cleaning of event listeners or subscriptions ( like socket.io events) let’s see how we can implement that.\n\n```js\nuseEffect(() => {\n    window.addEventListener(\'click\', () => console.log(\'capture clicks\'))\n    return () => {\n        window.removeEventListener(\'click\', () => console.log(\'clean clicks listener\'))\n    }\n}, [])\n```',NULL,0,'2020-05-04 06:21:17','2020-05-20 04:46:12','2020-05-18 14:47:33');
/*!40000 ALTER TABLE `threads` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutorial_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'brand-100',
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tutorial_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `tutorial_categories` DISABLE KEYS */;
INSERT INTO `tutorial_categories` (`id`, `name`, `color`, `slug`, `order`, `created_at`, `updated_at`) VALUES (1,'Laravel','brand-100','laravel',1,'2020-04-30 07:47:36','2020-04-30 07:47:36'),(2,'React','brand-100','react',1,'2020-04-30 07:47:36','2020-04-30 07:47:36'),(3,'React Native','brand-100','react-native',1,'2020-04-30 07:47:36','2020-04-30 07:47:36'),(4,'VueJS','brand-100','vue-js',1,'2020-04-30 07:47:36','2020-04-30 07:47:36'),(5,'Flutter','brand-100','flutter',1,'2020-04-30 07:47:36','2020-04-30 07:47:36'),(6,'Hosting','brand-100','hosting',1,'2020-04-30 07:47:36','2020-04-30 07:47:36'),(7,'Design','brand-100','design',1,'2020-04-30 07:47:36','2020-04-30 07:47:36');
/*!40000 ALTER TABLE `tutorial_categories` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutorial_tutorials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT','PENDING') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `visits` int unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tutorial_tutorials_slug_unique` (`slug`),
  KEY `tutorial_tutorials_category_id_foreign` (`category_id`),
  KEY `tutorial_tutorials_user_id_foreign` (`user_id`),
  CONSTRAINT `tutorial_tutorials_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `tutorial_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tutorial_tutorials_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `tutorial_tutorials` DISABLE KEYS */;
INSERT INTO `tutorial_tutorials` (`id`, `title`, `slug`, `body`, `summary`, `provider_id`, `provider`, `video_link`, `image`, `status`, `featured`, `visits`, `user_id`, `category_id`, `published_at`, `created_at`, `updated_at`) VALUES (1,'No one will tell you this, about web development in 2020','no-one-will-tell-you-this-about-web-development-in-2020','Do you want to become a Web Developer or are you interested in learning Web Development in 2020?\r\nThen, this is the beginning of a series of tutorials to become a full-stack web developer by the end of this upcoming year 2020. I will take you from beginner to expert for free. \r\nYou will learn Frontend Development from HTML5, CSS3, and JavaScript\r\nAfter that, we will go through Angular as a frontend framework.\r\nYou will also lear Backend Development with NodeJS and Laravel for PHP guys combining with MongoDB and MySQL.\r\nAfter all of these, we will build a Full-Flesh E-commerce Website to assimilate all that we have learned.\r\n\r\nget more frontend content on my website\r\n[BeePro](https://bproo.com/)','Do you want to become a Web Developer or are you interested in learning Web Development in 2020? Then, this is the beginning of a series of tutorials to become a full-stack web developer by the end of this upcoming year 2020.','17X-CKVOQ4I','youtube',NULL,NULL,'PUBLISHED',0,12,1,1,'2020-04-30 09:29:00','2020-04-30 09:29:42','2020-06-18 17:00:12'),(2,'Laravel Movie App - Adding Actors - Part 7','laravel-movie-app-adding-actors-part-7','We take a look at adding actors to our application. We make an index page of actors, take a look at pagination and implement infinite scroll as well. We also add the single actor page, with personal information along with their credits from past work.\r\n\r\nGitHub Repo: https://github.com/drehimself/laravel...\r\n\r\nTMDb API: https://www.themoviedb.org/documentat...\r\n\r\n# LINKS\r\nMy courses: [https://codewithdre.com](https://codewithdre.com)\r\n\r\nSign up for my newsletter: [http://andremadarang.com/newsletter](http://andremadarang.com/newsletter)\r\n\r\nMy website: [http://andremadarang.com](http://andremadarang.com)\r\n\r\nTwitter: [http://twitter.com/drehimself](http://twitter.com/drehimself)\r\n\r\nGitHub: [http://github.com/drehimself](http://github.com/drehimself)\r\n\r\nCodePen: [http://codepen.io/drehimself](http://codepen.io/drehimself)','We take a look at adding actors to our application. We make an index page of actors, take a look at pagination and implement infinite scroll as well. We also add the single actor page, with personal information along with their credits from past work.','AMaJx1dwYlE','youtube',NULL,NULL,'PUBLISHED',0,4,1,1,'2020-04-30 09:34:00','2020-04-30 09:34:47','2020-04-30 19:52:01');
/*!40000 ALTER TABLE `tutorial_tutorials` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gravatar',
  `avatar_location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `active` tinyint unsigned NOT NULL DEFAULT '1',
  `confirmation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_be_logged_out` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `uuid`, `first_name`, `last_name`, `username`, `email`, `avatar_type`, `avatar_location`, `password`, `phone_number`, `password_changed_at`, `active`, `confirmation_code`, `confirmed`, `last_login_at`, `last_login_ip`, `to_be_logged_out`, `remember_token`, `timezone`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'914f842c-be99-4ef1-8361-5f3975a8b8bb','Monney','Arthur','','monneylobe@gmail.com','storage','avatars/wea1VntjEFHhggZJAMbb36GhRaxW5QfI2dp62Vgm.jpeg','$2y$10$EZJnJVrDO2hxBdWopU9/Du6CHM7gsARsZlhaCx4BP89TJCbx/ndhK',NULL,NULL,1,'7624a46266539293f480c9b2a7e16b20',1,'2020-05-21 04:56:23','127.0.0.1',0,'jPSnUkp3PN8sqCrrpXUqohMZznunCCCmlF5suqgccBglEGTrD4Txe5g5kexW','America/New_York','2020-04-29 06:16:52','2020-05-21 04:56:23',NULL),(3,'504c01d1-4f4d-4df7-901a-b15004c85967','Mokam','Larissa','larissa','mokamtamnour@gmail.com','storage','avatars/JOE9u7K15eEp0Klw2E40QSPPlKGtyDSR75rZW5kL.jpeg','$2y$10$ZYQqaCzDRvwvCCnjnvSXs.5rifi62md8DQU..zGsWgOMYRNtrbNTe',NULL,NULL,1,'56c22e4ec7c989e8ace0e91cc5c17295',1,'2020-05-01 03:33:17','127.0.0.1',0,'nHCuWrkGSYxaHyIV1h4Gkueoug8cXwHDMJOaoBwxwMO2ABhKAQvrAyNNnFCs','America/New_York','2020-05-01 03:32:41','2020-05-01 03:34:09',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

